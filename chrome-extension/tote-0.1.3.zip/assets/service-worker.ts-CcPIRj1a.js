import{u as h}from"./capture-R-hHoMw3.js";chrome.runtime.onMessageExternal.addListener((r,a,e)=>r.type==="PING"?(e({success:!0,version:chrome.runtime.getManifest().version}),!0):r.type==="REFRESH_LINK"?(w(r.url,r.capture).then(t=>e({success:!0,metadata:t})).catch(t=>e({success:!1,error:t.message})),!0):r.type==="GET_ALL_TABS"?(p(a.origin).then(t=>e({success:!0,tabs:t})).catch(t=>e({success:!1,error:t.message})),!0):r.type==="EXTRACT_TAB_METADATA"?(T(r.tabId).then(t=>e({success:!0,metadata:t})).catch(t=>e({success:!1,error:t.message})),!0):!1);const f=["chrome://","chrome-extension://","about:","edge://","brave://","devtools://"];async function p(r){return(await chrome.tabs.query({})).filter(e=>!(!e.id||!e.url||r&&e.url.startsWith(r))).map(e=>{const t=e.url||"",o=!f.some(c=>t.startsWith(c));return{tabId:e.id,url:t,title:e.title||t,favIconUrl:e.favIconUrl,extractable:o}})}async function T(r){const a=await chrome.tabs.sendMessage(r,{type:"EXTRACT_METADATA"});if(a!=null&&a.error)throw new Error(a.error);if(!(a!=null&&a.data))throw new Error("No metadata extracted");return a.data}async function w(r,a){const e=await chrome.tabs.create({url:r,active:!1});if(!e.id)throw new Error("Failed to create tab");const t=e.id;try{await new Promise((i,u)=>{const d=setTimeout(()=>{chrome.tabs.onUpdated.removeListener(n),u(new Error("Page load timeout"))},15e3),n=(m,l)=>{m===t&&l.status==="complete"&&(chrome.tabs.onUpdated.removeListener(n),clearTimeout(d),i())};chrome.tabs.onUpdated.addListener(n)}),await new Promise(i=>setTimeout(i,500));const o=await chrome.tabs.sendMessage(t,{type:"EXTRACT_METADATA"});if(o!=null&&o.error)throw new Error(o.error);if(!(o!=null&&o.data))throw new Error("No metadata extracted");let c;if(a)try{const i=await chrome.tabs.sendMessage(t,{type:"CAPTURE_RAW_PAGE"});i!=null&&i.capture&&(c=h(i.capture))}catch{}try{await chrome.tabs.remove(t)}catch{}return c&&c.catch(()=>{}),o.data}catch(o){try{await chrome.tabs.remove(t)}catch{}throw o}}chrome.runtime.onInstalled.addListener(()=>{chrome.contextMenus.create({id:"save-to-tote",title:"Save to Tote",contexts:["page","link","image"]})});function s(r,a){chrome.scripting.executeScript({target:{tabId:r},func:e=>{const t=document.createElement("div");t.textContent=e,t.style.cssText=`
        position: fixed;
        bottom: 20px;
        right: 20px;
        background: #6366f1;
        color: white;
        padding: 12px 20px;
        border-radius: 8px;
        font-family: system-ui, sans-serif;
        font-size: 14px;
        z-index: 999999;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        animation: toteSlideIn 0.3s ease;
      `;const o=document.createElement("style");o.textContent=`
        @keyframes toteSlideIn {
          from { transform: translateX(100%); opacity: 0; }
          to { transform: translateX(0); opacity: 1; }
        }
      `,document.head.appendChild(o),document.body.appendChild(t),setTimeout(()=>{t.style.animation="toteSlideIn 0.3s ease reverse",setTimeout(()=>t.remove(),300)},3e3)},args:[a]})}chrome.contextMenus.onClicked.addListener(async(r,a)=>{if(!(r.menuItemId!=="save-to-tote"||!(a!=null&&a.id))){if(r.linkUrl){const e=await chrome.tabs.create({url:r.linkUrl,active:!0});if(!e.id)return;const t=async(o,c)=>{if(o===e.id&&c.status==="complete"){chrome.tabs.onUpdated.removeListener(t),await new Promise(i=>setTimeout(i,500));try{await chrome.action.openPopup()}catch{s(o,"Click the Tote icon in your toolbar to save this page")}}};chrome.tabs.onUpdated.addListener(t),setTimeout(()=>{chrome.tabs.onUpdated.removeListener(t)},1e4);return}try{await chrome.action.openPopup()}catch{s(a.id,"Click the Tote icon in your toolbar to save this page")}}});
